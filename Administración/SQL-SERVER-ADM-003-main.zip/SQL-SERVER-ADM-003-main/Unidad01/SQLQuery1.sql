



select @@Version;
go


