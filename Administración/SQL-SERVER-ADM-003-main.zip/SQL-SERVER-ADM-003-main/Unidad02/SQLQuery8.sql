

grant select on curso to public;
go


select * from edutec.dbo.alumno;
go