

grant select on curso to admdb;
go

grant select on alumno to admdb;
go



ALTER ROLE [db_datareader] ADD MEMBER [pepito]
GO